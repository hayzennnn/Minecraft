'use client'

import { useEffect, useMemo, useState } from 'react'

type Item = { Objet: string; Catégorie: string; 'Prix / stack de 64 ($)'?: number; 'Prix / unité ($)'?: number; 'Rareté estimée'?: string; 'Justification économique'?: string }
type CartLine = { item: Item; quantity: number }
type Promo = { id: number; title: string; detail: string; active: boolean; image: string; badge: string }

const fallbackItems: Item[] = [
  { Objet: 'Bambou', Catégorie: 'Agriculture', 'Prix / stack de 64 ($)': 16, 'Rareté estimée': 'Très commune', 'Justification économique': 'Croissance rapide et facilement automatisable.' },
  { Objet: 'Blé', Catégorie: 'Agriculture', 'Prix / stack de 64 ($)': 22.4, 'Rareté estimée': 'Très commune', 'Justification économique': 'Culture renouvelable et facile à automatiser.' },
  { Objet: 'Cactus', Catégorie: 'Agriculture', 'Prix / stack de 64 ($)': 44.8, 'Rareté estimée': 'Peu commun', 'Justification économique': "L'absence de désert rend sa disponibilité moins confortable." },
  { Objet: 'Potion de rapidité', Catégorie: 'Alchimie', 'Prix / stack de 64 ($)': 640, 'Rareté estimée': 'Peu commune', 'Justification économique': 'Préparation et accès au Nether inclus.' },
  { Objet: 'Poudre de blaze', Catégorie: 'Alchimie', 'Prix / stack de 64 ($)': 192, 'Rareté estimée': 'Peu commune', 'Justification économique': 'Ressource dangereuse et recherchée.' },
  { Objet: 'Œuf de dragon', Catégorie: 'Raretés', 'Prix / stack de 64 ($)': 50000, 'Rareté estimée': 'Unique', 'Justification économique': 'Objet trophée, disponible sur demande.' },
]

const initialPromos: Promo[] = [
  { id: 1, title: 'La récolte en folie', detail: '-10% sur le bambou, le blé et le cactus cette semaine', badge: '-10%', image: '/assets/promo-farm.png', active: true },
  { id: 2, title: 'Trésors du Nether', detail: 'Poudre de blaze et potions à prix cassés', badge: 'HOT', image: '/assets/promo-potions.png', active: true },
  { id: 3, title: 'Pièce mythique', detail: 'Une offre rare sur l’œuf de dragon, sur demande', badge: 'RARE', image: '/assets/promo-rare.png', active: true },
]

function money(value: number) { return `${value.toLocaleString('fr-FR', { maximumFractionDigits: 2 })} $` }

export default function Page() {
  const [items, setItems] = useState<Item[]>(fallbackItems)
  const [cart, setCart] = useState<CartLine[]>([])
  const [promos, setPromos] = useState<Promo[]>(initialPromos)
  const [view, setView] = useState<'home' | 'catalogue' | 'admin'>('home')
  const [query, setQuery] = useState('')
  const [cartOpen, setCartOpen] = useState(false)
  const [checkoutOpen, setCheckoutOpen] = useState(false)
  const [adminTab, setAdminTab] = useState<'catalogue' | 'promos'>('catalogue')
  const [notice, setNotice] = useState('')
  const [newPromo, setNewPromo] = useState({ title: '', detail: '' })
  const [adminAuth, setAdminAuth] = useState<{ username: string } | null>(null)
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login')
  const [authOpen, setAuthOpen] = useState(false)

  useEffect(() => { fetch('/data/catalogue.json').then(r => r.json()).then(data => Array.isArray(data) && setItems(data)).catch(() => {}) }, [])
  useEffect(() => { const saved = sessionStorage.getItem('tfpc-admin-session'); if (saved) setAdminAuth(JSON.parse(saved)) }, [])
  const openAdmin = () => { setAuthMode('login'); setAuthOpen(true) }
  const handleAdminAuth = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const username = String(form.get('username') || '').trim()
    const password = String(form.get('password') || '')
    const accounts = JSON.parse(localStorage.getItem('tfpc-admin-accounts') || '[]') as { username: string; password: string }[]
    if (!username || password.length < 6) return setNotice('Identifiant requis et mot de passe de 6 caractères minimum.')
    if (authMode === 'register') {
      if (accounts.length >= 2) return setNotice('La création de comptes est fermée : les 2 places admin sont déjà utilisées.')
      if (accounts.some(account => account.username.toLowerCase() === username.toLowerCase())) return setNotice('Cet identifiant existe déjà.')
      localStorage.setItem('tfpc-admin-accounts', JSON.stringify([...accounts, { username, password }]))
      setNotice('Compte admin créé. Connecte-toi pour continuer.')
      setAuthMode('login')
      return
    }
    const account = accounts.find(item => item.username === username && item.password === password)
    if (!account) return setNotice('Identifiant ou mot de passe incorrect.')
    const session = { username: account.username }
    sessionStorage.setItem('tfpc-admin-session', JSON.stringify(session))
    setAdminAuth(session); setAuthOpen(false); setView('admin')
  }

  const filtered = useMemo(() => items.filter(item => `${item.Objet} ${item.Catégorie}`.toLowerCase().includes(query.toLowerCase())).slice(0, 36), [items, query])
  const total = cart.reduce((sum, line) => sum + (Number(line.item['Prix / stack de 64 ($)']) || Number(line.item['Prix / unité ($)']) * 64 || 0) * line.quantity, 0)
  const add = (item: Item) => { setCart(lines => { const existing = lines.find(line => line.item.Objet === item.Objet); return existing ? lines.map(line => line.item.Objet === item.Objet ? { ...line, quantity: line.quantity + 1 } : line) : [...lines, { item, quantity: 1 }] }); setNotice(`${item.Objet} ajouté au panier`) }
  const remove = (name: string) => setCart(lines => lines.filter(line => line.item.Objet !== name))
  const submitOrder = (event: React.FormEvent<HTMLFormElement>) => { event.preventDefault(); setCart([]); setCheckoutOpen(false); setCartOpen(false); setNotice('Commande enregistrée. Nous revenons vers toi pour le paiement et la livraison.') }

  return <div className="site-shell">
    <header className="topbar"><a className="brand" href="#" onClick={() => setView('home')}><img src="/assets/logo.svg" alt="Tout faire pas cher" /></a><nav><button onClick={() => setView('home')}>Accueil</button><button onClick={() => setView('catalogue')}>Catalogue</button><button onClick={() => setView('catalogue')}>Services</button><button className="admin-link" onClick={openAdmin}>Admin</button></nav><button className="cart-button" onClick={() => setCartOpen(true)}>Panier <b>{cart.reduce((sum, line) => sum + line.quantity, 0)}</b></button></header>
    {notice && <div className="toast" role="status">{notice}<button onClick={() => setNotice('')}>×</button></div>}
    {view === 'admin' && adminAuth ? <Admin items={items} setItems={setItems} promos={promos} setPromos={setPromos} tab={adminTab} setTab={setAdminTab} newPromo={newPromo} setNewPromo={setNewPromo} /> : <>
      {view === 'home' && <><section className="hero"><div><span className="eyebrow">Boutique Minecraft • simple et fiable</span><h1>Tout faire pas cher.<br /><em>Oui, on peut.</em></h1><p>Ressources, objets rares, fermes et services sur mesure. Ajoute ce dont tu as besoin au panier, puis indique ton pseudo au moment de commander.</p><div className="hero-actions"><button className="primary" onClick={() => setView('catalogue')}>Voir le catalogue</button><button className="secondary" onClick={() => setCartOpen(true)}>Ouvrir le panier</button></div></div><div className="hero-image"><img src="/assets/hero.svg" alt="Paysage Minecraft nocturne" /></div></section><section className="promo-strip"><div className="promo-heading"><span className="eyebrow">Offres limitées</span><h2>Les promos qui font plaisir</h2><p>Des prix boostés, des stocks limités. Profite-en avant que les coffres soient vides.</p></div><div className="promo-grid">{promos.filter(p => p.active).map(p => <article className="promo-card" key={p.id}><img src={p.image} alt="" /><div className="promo-overlay"><b className="promo-badge">{p.badge}</b><strong>{p.title}</strong><span>{p.detail}</span><button onClick={() => setView('catalogue')}>Profiter de l’offre</button></div></article>)}</div></section></>}
      <section className="catalogue" id="catalogue"><div className="section-heading"><div><span className="eyebrow">Catalogue</span><h2>{view === 'home' ? 'Les incontournables' : 'Tous les objets disponibles'}</h2></div><input aria-label="Rechercher un objet" placeholder="Rechercher un objet…" value={query} onChange={e => setQuery(e.target.value)} /></div><div className="category-row"><button onClick={() => setQuery('Agriculture')}>Agriculture</button><button onClick={() => setQuery('Alchimie')}>Alchimie</button><button onClick={() => setQuery('Raretés')}>Objets rares</button><button onClick={() => setQuery('')}>Tout afficher</button></div><div className="product-grid">{filtered.slice(0, view === 'home' ? 6 : 36).map(item => <article className="product-card" key={item.Objet}><div className="product-art"><img src={item.Catégorie === 'Agriculture' ? '/assets/promo-farm.png' : item.Catégorie === 'Raretés' ? '/assets/promo-rare.png' : '/assets/promo-potions.png'} alt="" /><span>{item.Catégorie === 'Agriculture' ? '✦' : item.Catégorie === 'Raretés' ? '◆' : '◈'}</span></div><div className="product-body"><small>{item.Catégorie}</small><h3>{item.Objet}</h3><p>{item['Justification économique'] || 'Article disponible sur commande.'}</p><div className="product-footer"><strong>{money(Number(item['Prix / stack de 64 ($)']) || Number(item['Prix / unité ($)']) * 64 || 0)}</strong><button onClick={() => add(item)}>Ajouter</button></div></div></article>)}</div></section>
    </>}
    <footer>© Tout faire pas cher • Minecraft Java • Prix indicatifs du serveur</footer>
    {cartOpen && <aside className="drawer" aria-label="Panier"><div className="drawer-head"><h2>Ton panier</h2><button onClick={() => setCartOpen(false)}>×</button></div>{cart.length === 0 ? <p className="empty">Ton panier est vide. Ajoute des objets depuis le catalogue.</p> : <>{cart.map(line => <div className="cart-line" key={line.item.Objet}><div><b>{line.item.Objet}</b><span>{line.quantity} stack · {money((Number(line.item['Prix / stack de 64 ($)']) || 0) * line.quantity)}</span></div><button onClick={() => remove(line.item.Objet)}>Retirer</button></div>)}<div className="cart-total"><span>Total estimé</span><strong>{money(total)}</strong></div><button className="primary full" onClick={() => setCheckoutOpen(true)}>Passer à la commande</button></>}</aside>}
    {checkoutOpen && <div className="modal-backdrop"><form className="checkout modal-card" onSubmit={submitOrder}><button type="button" className="modal-close" onClick={() => setCheckoutOpen(false)}>×</button><span className="eyebrow">Dernière étape</span><h2>Qui doit recevoir la commande ?</h2><p>Le panier est conservé pendant que tu renseignes tes informations.</p><label>Pseudo Minecraft *<input required name="player" placeholder="Ton pseudo" /></label><label>Contact (Discord, etc.)<input name="contact" placeholder="Optionnel" /></label><label>Précision de livraison<textarea name="note" placeholder="Coordonnées, horaire ou demande particulière…" /></label><div className="checkout-total"><span>Total à confirmer</span><b>{money(total)}</b></div><button className="primary full">Confirmer ma commande</button></form></div>}
    {authOpen && <div className="modal-backdrop"><form className="modal-card admin-auth" onSubmit={handleAdminAuth}><button type="button" className="modal-close" onClick={() => setAuthOpen(false)}>×</button><span className="eyebrow">Accès réservé</span><h2>{authMode === 'login' ? 'Connexion admin' : 'Créer un compte admin'}</h2><p>{authMode === 'login' ? 'Connecte-toi pour gérer la boutique.' : 'Seulement 2 comptes peuvent être créés. Après cela, les inscriptions sont définitivement fermées.'}</p><label>Identifiant<input required name="username" autoComplete="username" /></label><label>Mot de passe<input required minLength={6} type="password" name="password" autoComplete={authMode === 'login' ? 'current-password' : 'new-password'} /></label><button className="primary full">{authMode === 'login' ? 'Se connecter' : 'Créer le compte'}</button>{authMode === 'login' && <button type="button" className="auth-switch" onClick={() => setAuthMode('register')}>Créer l’un des 2 comptes</button>}{authMode === 'register' && <button type="button" className="auth-switch" onClick={() => setAuthMode('login')}>Retour à la connexion</button>}</form></div>}
  </div>
}

function Admin({ items, setItems, promos, setPromos, tab, setTab, newPromo, setNewPromo }: { items: Item[]; setItems: React.Dispatch<React.SetStateAction<Item[]>>; promos: Promo[]; setPromos: React.Dispatch<React.SetStateAction<Promo[]>>; tab: 'catalogue' | 'promos'; setTab: (tab: 'catalogue' | 'promos') => void; newPromo: { title: string; detail: string }; setNewPromo: React.Dispatch<React.SetStateAction<{ title: string; detail: string }>> }) {
  const [editing, setEditing] = useState<Item | null>(null)
  const saveItem = (event: React.FormEvent<HTMLFormElement>) => { event.preventDefault(); if (!editing) return; setItems(current => current.some(item => item.Objet === editing.Objet) ? current.map(item => item.Objet === editing.Objet ? editing : item) : [editing, ...current]); setEditing(null) }
  return <main className="admin-page"><div className="admin-hero"><div><span className="eyebrow">Espace gestion</span><h1>Admin boutique</h1><p>Modifie les prix, les descriptions et les promotions visibles sur l'accueil.</p></div><button className="secondary" onClick={() => setTab('catalogue')}>Retour boutique</button></div><div className="admin-tabs"><button className={tab === 'catalogue' ? 'selected' : ''} onClick={() => setTab('catalogue')}>Objets & prix</button><button className={tab === 'promos' ? 'selected' : ''} onClick={() => setTab('promos')}>Promotions</button></div>{tab === 'catalogue' ? <section className="admin-panel"><div className="panel-head"><div><h2>Catalogue</h2><p>{items.length} objets gérés depuis cet onglet</p></div><button className="primary" onClick={() => setEditing({ Objet: '', Catégorie: 'Agriculture', 'Prix / stack de 64 ($)': 0, 'Justification économique': '' })}>Ajouter un objet</button></div><div className="admin-list">{items.slice(0, 30).map(item => <div className="admin-row" key={item.Objet}><div><b>{item.Objet}</b><span>{item.Catégorie} · {money(Number(item['Prix / stack de 64 ($)']) || 0)}</span></div><button onClick={() => setEditing({ ...item })}>Modifier</button></div>)}</div></section> : <section className="admin-panel"><div className="panel-head"><div><h2>Promotions publiques</h2><p>Les promotions actives apparaissent automatiquement sur l'accueil.</p></div></div><div className="promo-form"><input placeholder="Titre de la promo" value={newPromo.title} onChange={e => setNewPromo({ ...newPromo, title: e.target.value })} /><input placeholder="Détail visible par les clients" value={newPromo.detail} onChange={e => setNewPromo({ ...newPromo, detail: e.target.value })} /><button className="primary" onClick={() => { if (newPromo.title && newPromo.detail) { setPromos([...promos, { ...newPromo, id: Date.now(), badge: 'NEW', image: '/assets/promo-farm.png', active: true }]); setNewPromo({ title: '', detail: '' }) } }}>Publier</button></div><div className="admin-list">{promos.map(p => <div className="admin-row" key={p.id}><div><b>{p.title}</b><span>{p.detail}</span></div><div><button onClick={() => setPromos(promos.map(x => x.id === p.id ? { ...x, active: !x.active } : x))}>{p.active ? 'Masquer' : 'Afficher'}</button><button className="danger" onClick={() => setPromos(promos.filter(x => x.id !== p.id))}>Supprimer</button></div></div>)}</div></section>}{editing && <div className="modal-backdrop"><form className="modal-card admin-form" onSubmit={saveItem}><button type="button" className="modal-close" onClick={() => setEditing(null)}>×</button><h2>{editing.Objet ? 'Modifier l’objet' : 'Nouvel objet'}</h2><label>Nom<input required value={editing.Objet} onChange={e => setEditing({ ...editing, Objet: e.target.value })} /></label><label>Catégorie<input value={editing.Catégorie} onChange={e => setEditing({ ...editing, Catégorie: e.target.value })} /></label><label>Prix par stack<input type="number" min="0" step="0.01" value={editing['Prix / stack de 64 ($)'] || 0} onChange={e => setEditing({ ...editing, 'Prix / stack de 64 ($)': Number(e.target.value) })} /></label><label>Description<textarea value={editing['Justification économique'] || ''} onChange={e => setEditing({ ...editing, 'Justification économique': e.target.value })} /></label><button className="primary full">Enregistrer</button></form></div>}</main>
}
